import { motion } from "motion/react";
import { 
  MessageSquare, 
  Mic2, 
  Users, 
  Shield, 
  Image as ImageIcon, 
  Smile, 
  Link as LinkIcon, 
  ArrowRight,
  CheckCircle2,
  XCircle,
  Gamepad2,
  GraduationCap,
  Rocket,
  Instagram,
  Twitter,
  MessageCircle
} from "lucide-react";

const FeatureCard = ({ icon: Icon, title, description, badge }: { icon: any, title: string, description?: string, badge?: string }) => (
  <motion.div 
    whileHover={{ y: -5, scale: 1.02 }}
    className="glass p-6 rounded-2xl flex flex-col gap-4 relative overflow-hidden group"
  >
    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
    <div className="w-12 h-12 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
      <Icon size={24} />
    </div>
    <div>
      <h3 className="text-xl font-display font-semibold text-white flex items-center gap-2">
        {title}
        {badge && <span className="text-[10px] uppercase tracking-wider bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30">{badge}</span>}
      </h3>
      {description && <p className="text-slate-400 mt-2 text-sm leading-relaxed">{description}</p>}
    </div>
  </motion.div>
);

const ComparisonItem = ({ title, items, type }: { title: string, items: string[], type: 'negative' | 'positive' }) => (
  <div className={`p-8 rounded-3xl ${type === 'positive' ? 'glass border-indigo-500/30 bg-indigo-500/5' : 'bg-white/5'}`}>
    <h3 className={`text-2xl font-display font-bold mb-6 ${type === 'positive' ? 'text-indigo-400' : 'text-slate-400'}`}>
      {title}
    </h3>
    <ul className="space-y-4">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-3">
          {type === 'positive' ? (
            <CheckCircle2 className="text-indigo-400 shrink-0 mt-1" size={20} />
          ) : (
            <XCircle className="text-red-400/50 shrink-0 mt-1" size={20} />
          )}
          <span className="text-slate-300">{item}</span>
        </li>
      ))}
    </ul>
  </div>
);

const ExampleCard = ({ title, icon: Icon, spaces }: { title: string, icon: any, spaces: { name: string, type: 'text' | 'voice' }[] }) => (
  <div className="glass p-8 rounded-3xl">
    <div className="flex items-center gap-4 mb-8">
      <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
        <Icon size={24} className="text-indigo-400" />
      </div>
      <h3 className="text-2xl font-display font-bold text-white">{title}</h3>
    </div>
    <div className="space-y-3">
      <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-2">Spaces</p>
      {spaces.map((space, i) => (
        <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 transition-colors">
          {space.type === 'voice' ? <Mic2 size={16} className="text-indigo-400" /> : <MessageSquare size={16} className="text-slate-400" />}
          <span className="text-slate-200 font-medium">{space.name}</span>
          {space.type === 'voice' && <span className="ml-auto text-[10px] text-indigo-400 font-bold uppercase">Voice Space</span>}
        </div>
      ))}
    </div>
  </div>
);

export default function App() {
  return (
    <div className="min-h-screen font-sans">
      {/* Background Elements */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/20 blur-[120px] rounded-full" />
      </div>

      {/* Navbar */}
      <nav className="sticky top-0 z-50 glass border-x-0 border-t-0">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Rocket className="text-white" size={20} />
            </div>
            <span className="text-2xl font-display font-extrabold tracking-tight text-white">Ballastra</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#examples" className="hover:text-white transition-colors">Examples</a>
            <a href="#audience" className="hover:text-white transition-colors">Who it's for</a>
          </div>
          <button className="btn-primary py-2 px-5 text-sm">
            Join Waitlist
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-32 px-6 relative overflow-hidden">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-3 px-6 py-2.5 rounded-full glass border-indigo-500/30 text-indigo-300 text-lg font-bold mb-10 shadow-xl shadow-indigo-500/10"
          >
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
            </span>
            🚀 Launching March 9
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-extrabold text-white mb-8 leading-[1.1] tracking-tight"
          >
            Build Powerful Communities. <br />
            <span className="text-gradient">Not Chaotic Chats.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto leading-relaxed"
          >
            Create structured communities using Spaces, Voice Spaces, and powerful control tools.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col items-center gap-4"
          >
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <button className="btn-primary flex items-center justify-center gap-2 group">
                Download for Android
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="btn-secondary">
                Join Waitlist
              </button>
            </div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-widest">
              iOS coming soon.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-white mb-4">Everything you need</h2>
            <p className="text-slate-400">Powerful tools to keep your community organized and engaged.</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard icon={MessageSquare} title="Text Chat" description="High-performance text messaging with rich formatting and thread support." />
            <FeatureCard icon={ImageIcon} title="Share Media" description="Seamlessly share images, videos, and files with high-quality previews." />
            <FeatureCard icon={Smile} title="Emoji Reactions" description="Express yourself with custom emoji reactions on any message." />
            <FeatureCard icon={Mic2} title="Voice Spaces" description="Crystal clear low-latency voice conversations for your community." />
            <FeatureCard icon={Users} title="Manage Members" description="Advanced moderation tools to keep your community safe and welcoming." />
            <FeatureCard icon={LinkIcon} title="Invite Links" description="Create custom invite links with expiration and usage limits." />
            <FeatureCard icon={Shield} title="Ident System" badge="Coming Soon" description="A revolutionary way to manage roles and permissions within your community." />
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-white mb-4">Why Ballastra?</h2>
            <p className="text-slate-400">Traditional chat apps weren't built for communities. We are.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <ComparisonItem 
              title="Standard Chat Apps" 
              type="negative"
              items={[
                "Messages get buried in a single stream",
                "No structure for different topics",
                "Hard to manage large communities",
                "Chaos as the group grows"
              ]}
            />
            <ComparisonItem 
              title="Ballastra" 
              type="positive"
              items={[
                "Organized Spaces for every topic",
                "Voice Spaces for real-time conversations",
                "Structured community control tools",
                "Scales effortlessly with your growth"
              ]}
            />
          </div>
        </div>
      </section>

      {/* Community Examples */}
      <section id="examples" className="py-24 px-6 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-white mb-4">Built for Structure</h2>
            <p className="text-slate-400">See how different communities organize their Spaces.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <ExampleCard 
              title="Gaming Community" 
              icon={Gamepad2}
              spaces={[
                { name: "announcements", type: "text" },
                { name: "game-chat", type: "text" },
                { name: "voice-lobby", type: "voice" }
              ]}
            />
            <ExampleCard 
              title="Coaching Community" 
              icon={GraduationCap}
              spaces={[
                { name: "notes", type: "text" },
                { name: "doubts", type: "text" },
                { name: "live-session", type: "voice" }
              ]}
            />
          </div>
        </div>
      </section>

      {/* Target Audience */}
      <section id="audience" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-white mb-4">Who is it for?</h2>
            <p className="text-slate-400">Ballastra empowers leaders across all industries.</p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4">
            {["Gaming Communities", "Coaching Platforms", "Startup Communities", "Private Groups", "School Admins"].map((item, i) => (
              <motion.div 
                key={i}
                whileHover={{ scale: 1.05 }}
                className="px-8 py-4 rounded-2xl glass font-display font-bold text-xl text-white hover:text-indigo-400 transition-colors cursor-default"
              >
                {item}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                  <Rocket className="text-white" size={16} />
                </div>
                <span className="text-xl font-display font-extrabold tracking-tight text-white">Ballastra</span>
              </div>
              <p className="text-slate-400 max-w-sm leading-relaxed">
                The next generation of community building. Structured, powerful, and built for you.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6">Connect</h4>
              <div className="flex flex-col gap-4 text-slate-400 text-sm">
                <a href="#" className="flex items-center gap-2 hover:text-white transition-colors">
                  <Instagram size={18} /> Instagram
                </a>
                <a href="#" className="flex items-center gap-2 hover:text-white transition-colors">
                  <Twitter size={18} /> Twitter / X
                </a>
                <a href="#" className="flex items-center gap-2 hover:text-white transition-colors">
                  <MessageCircle size={18} /> Discord Community
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6">Support</h4>
              <p className="text-slate-400 text-sm mb-2">Have questions?</p>
              <a href="mailto:support@ballastra.app" className="text-indigo-400 font-medium hover:text-indigo-300 transition-colors">
                support@ballastra.app
              </a>
            </div>
          </div>
          
          <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-xs">
              © 2025 Ballastra Platform. All rights reserved.
            </p>
            <div className="flex gap-6 text-xs text-slate-500">
              <a href="#" className="hover:text-slate-300 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-slate-300 transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
